//  $("div").css("color", "blue");

class Animal {
    constructor(name) {
        this.name = '';
        this.owner = '';
        this.age = -1;
        this.vaccines = [];
    }
    static eat(){
        console.log('eating ...');}
}

Animal.IS_ALIVE = true;

Animal.eat();

class Dog extends Animal {
    //Animal.call(this);      //inheriting
    
    constructor(name, trick, city) {
        super(name);        //Get the methods from the Animals constructor (inheritance), 
        this.trick = trick;
        this.eyeColor = 'yellow';
        this.city = city;
    }
    eat() {
        console.log('chewong..');}
    bark() {
        console.log('woof-woof');}
    bark(timer){
        for(let i=0 ;i< timer ;i++){
            console.log('woof');}
        }
}

let puppy = new Dog('Rex', null, 'Cluj');
console.log('trick = ' + puppy.trick);
console.log('city = ' + puppy.city);

Dog.prototype.LEGS = 4;

class Cat extends Animal{
    // Animal.call(this);     //inheriting
    constructor(name, climbing) {
        super(name);        //the 'name' sending to the animal
        this.climbing = climbing;
    }
    eat() {
        console.log('licking...');}
    meow() { 
        console.log('meoooww...');}
}

let kitty = new Cat('Tom', 'higher');
kitty.age = 3;
kitty.eat();

// let puppy = new Dog('rolling...');
// console.log('trick = ' + puppy.trick);

puppy.age = 5;
puppy.eat();
puppy.bark(3);
console.log("* " + puppy.eyeColor);
puppy.eyeColor = 'blue';
console.log("* " + puppy.eyeColor);
// console.log("- " + puppy.LEGS);
Dog.prototype.LEGS = 3;        //This will affect all instances
// console.log("- " + puppy.LEGS);
console.group("*** " + Animal.IS_ALIVE);

let pets = [puppy, kitty];

for (pet of pets) {
    pet.eat();

}

