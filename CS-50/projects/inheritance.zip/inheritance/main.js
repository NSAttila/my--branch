// //  $("div").css("color", "blue");

// function Animal() {
//     this.name = '';
//     this.owner = '';
//     this.age = -1;
//     this.vaccines = []; 
// }
// Animal.IS_ALIVE = true;

// Animal.prototype.eat = function() {
//     console.log('eating ...');
// }

// function Dog() {
//     Animal.call(this);      //inheriting
//     this.trick = '';
//     this.eyeColor = 'yellow';
// }
// Dog.prototype.LEGS = 4;
// Dog.prototype.eat = function() {
//     // Animal.prototype.eat();
//     console.log('chewong..')

// }
// Dog.prototype.bark = function () {
//     console.log('woof-woof');
// }
// Dog.prototype.bark = function (timer) {
//     // interate  'woof' x times
//     for(var i=0 ;i< timer ;i++){
//         console.log('woof');
//     }

// }


// function Cat() {
//     Animal.call(this);     //inheriting
//     this.climbing = '';
// }
// Cat.prototype.eat = function() {
//     // Animal.prototype.eat();
//     console.log('licking...');
// }
// Cat.prototype.meow = function() {
//     console.log('meoooww...');
// }

// var puppy = new Dog();
// puppy.name = 'Rex';
// puppy.age = 5;
// puppy.eat();
// puppy.bark(3);
// console.log("* " + puppy.eyeColor);
// puppy.eyeColor = 'blue';
// console.log("* " + puppy.eyeColor);
// // console.log("- " + puppy.LEGS);
// Dog.prototype.LEGS = 3;        //This will affect all instances
// // console.log("- " + puppy.LEGS);
// console.group("*** " + Animal.IS_ALIVE);


// var kitty = new Cat();
// kitty.name = 'Tom';
// kitty.age = 3;
// kitty.eat();

// var pets = [puppy, kitty];

// for (var pet of pets) {
//     pet.eat();

// }

//  $("div").css("color", "blue");

function Animal() {
    this.name = '';
    this.owner = '';
    this.age = -1;
    this.vaccines = []; 
}

static eat() {
    console.log('eating...');
}

//getter
get Age() {
    return this.age;
}

//

Animal.IS_ALIVE = true;

Animal.prototype.eat = function() {
    console.log('eating ...');
}

function Dog() {
    Animal.call(this);      //inheriting
    this.trick = '';
    this.eyeColor = 'yellow';
}
Dog.prototype.LEGS = 4;
Dog.prototype.eat = function() {
    // Animal.prototype.eat();
    console.log('chewong..')

}
Dog.prototype.bark = function () {
    console.log('woof-woof');
}
Dog.prototype.bark = function (timer) {
    // interate  'woof' x times
    for(var i=0 ;i< timer ;i++){
        console.log('woof');
    }

}


function Cat() {
    Animal.call(this);     //inheriting
    this.climbing = '';
}
Cat.prototype.eat = function() {
    // Animal.prototype.eat();
    console.log('licking...');
}
Cat.prototype.meow = function() {
    console.log('meoooww...');
}

var puppy = new Dog();
puppy.name = 'Rex';
puppy.age = 5;
puppy.eat();
puppy.bark(3);
console.log("* " + puppy.eyeColor);
puppy.eyeColor = 'blue';
console.log("* " + puppy.eyeColor);
// console.log("- " + puppy.LEGS);
Dog.prototype.LEGS = 3;        //This will affect all instances
// console.log("- " + puppy.LEGS);
console.group("*** " + Animal.IS_ALIVE);


var kitty = new Cat();
kitty.name = 'Tom';
kitty.age = 3;
kitty.eat();

var pets = [puppy, kitty];

for (var pet of pets) {
    pet.eat();

}

